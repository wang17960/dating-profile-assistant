/* 检查合成资料与真实题库、公开规则和版本协议的一致性。 */
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {model, questions, root} = require("./helpers.cjs");
const fixtures = JSON.parse(fs.readFileSync(path.join(root, "tests/content-cases.json"), "utf8"));

test("固定案例包含12组不同的合成场景，全部题号可构建", () => {
  assert.equal(fixtures.synthetic, true);
  assert.equal(fixtures.cases.length, 12);
  assert.equal(new Set(fixtures.cases.map((c) => c.id)).size, 12);
  const ids = new Set(questions.map((q) => q.id));
  for (const c of fixtures.cases) for (const id of Object.keys(c.prefill.answers)) assert.ok(ids.has(id), `${c.id}/${id}`);
});

for (const c of fixtures.cases) {
  test(`${c.id} ${c.name}：载荷可读取且组合数量准确`, () => {
    const s = model.createState({questions, prefill: c.prefill});
    const body = JSON.parse(model.prompt(s).split("DATING_FORM_V1\n")[1]);
    assert.equal(body.draft_variants.length, c.expectations.variants);
    assert.equal(body.goal, c.prefill.goal);
    for (const a of body.answers) {
      if (a.status !== "answered" || a.kind !== "personal" || body.privacy_constraints.blocked_ids.includes(a.id)) {
        assert.equal(a.disclosure, "analysis_only", `${c.id}/${a.id}`);
      }
    }
    if (c.id === "C07") assert.equal(body.answers.find((a) => a.id === "q79").status, "skipped");
    if (c.id === "C05") assert.equal(body.answers.find((a) => a.id === "q52").evidence, "preference");
  });
}
