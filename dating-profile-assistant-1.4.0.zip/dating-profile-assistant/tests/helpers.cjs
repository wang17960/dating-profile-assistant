/* 从真实 Markdown 题库构建测试配置，不另造题目和选项。 */
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const vm = require("node:vm");
const {execFileSync} = require("node:child_process");
const root = path.resolve(__dirname, "..");
const bundledPython = path.join(os.homedir(), ".cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe");
const python = process.env.PYTHON_EXECUTABLE || (fs.existsSync(bundledPython) ? bundledPython : "python");
const questions = JSON.parse(execFileSync(python, ["-c",
  "import json,sys; sys.path.insert(0,sys.argv[1]); import build_form; print(json.dumps(build_form.load_questions(),ensure_ascii=False))",
  path.join(root, "scripts")], {encoding: "utf8", env: {...process.env, PYTHONIOENCODING: "utf-8"}}));
const context = vm.createContext({});
vm.runInContext(fs.readFileSync(path.join(root, "assets/form-model.js"), "utf8"), context);
module.exports = {root, python, questions, model: context.DatingForm,
  plain: (value) => JSON.parse(JSON.stringify(value))};
