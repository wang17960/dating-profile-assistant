"""统一启动、预填、迁移与失败恢复；不打开真实浏览器。"""

import json
import os
import subprocess
import sys
import unittest
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))


class StartFormTests(unittest.TestCase):
    def start(self, *args, **kwargs):
        import start_form
        return start_form.start_form(*args, **kwargs)

    def test_unique_pages_with_chinese_space_path_and_prefill(self):
        with TemporaryDirectory(prefix="合成 填写 ") as folder:
            base = Path(folder)
            prefill = base / "合成 预填.json"
            prefill.write_text(json.dumps({"goal": "report", "answers": {
                "q02": {"value": "29岁"}}}), encoding="utf-8-sig")
            first = self.start(base, prefill, no_open=True)
            second = self.start(base, no_open=True)
            self.assertNotEqual(first["html_path"], second["html_path"])
            self.assertFalse(first["browser_opened"])
            document = Path(first["html_path"]).read_text(encoding="utf-8")
            self.assertIn('"goal": "report"', document)
            self.assertIn("29岁", document)
            self.assertTrue(Path(second["html_path"]).is_file())

    def test_browser_rejection_retains_page_and_retry_works(self):
        import start_form
        with TemporaryDirectory() as folder:
            with patch.object(start_form, "open_form", return_value=False):
                rejected = self.start(folder)
            self.assertFalse(rejected["browser_opened"])
            self.assertTrue(Path(rejected["html_path"]).is_file())
            with patch.object(start_form, "open_form", return_value=True) as opener:
                restored = self.start(folder)
            self.assertTrue(restored["browser_opened"])
            opener.assert_called_once_with(Path(restored["html_path"]))

    def test_invalid_input_leaves_no_partial_page_then_can_retry(self):
        with TemporaryDirectory() as folder:
            base = Path(folder)
            prefill = base / "input.json"
            prefill.write_text('{"goal":"invalid"}', encoding="utf-8")
            with self.assertRaises(ValueError):
                self.start(base, prefill, no_open=True)
            self.assertEqual(list(base.glob("*.html")), [])
            self.assertTrue(Path(self.start(base, no_open=True)["html_path"]).is_file())

    def test_cli_returns_json_without_opening_browser(self):
        with TemporaryDirectory() as folder:
            result = subprocess.run([sys.executable, str(ROOT / "scripts/start_form.py"),
                                     "--output-dir", folder, "--no-open"],
                                    capture_output=True, encoding="utf-8", check=True,
                                    env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            data = json.loads(result.stdout)
            self.assertTrue(Path(data["html_path"]).is_file())
            self.assertFalse(data["browser_opened"])

    def test_cli_invalid_json_has_failure_status(self):
        with TemporaryDirectory() as folder:
            prefill = Path(folder) / "bad.json"
            prefill.write_text("not json", encoding="utf-8")
            result = subprocess.run([sys.executable, str(ROOT / "scripts/start_form.py"),
                                     "--output-dir", folder, "--prefill", str(prefill), "--no-open"],
                                    capture_output=True, encoding="utf-8",
                                    env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "")
            self.assertNotIn("Traceback", result.stderr)

    def test_no_open_preserves_existing_page_and_never_calls_browser(self):
        import start_form
        with TemporaryDirectory() as folder:
            existing = Path(folder) / "dating-profile-questionnaire-existing.html"
            existing.write_text("正在填写的页面", encoding="utf-8")
            with patch.object(start_form, "open_form") as opener:
                created = self.start(folder, no_open=True)
            opener.assert_not_called()
            self.assertNotEqual(Path(created["html_path"]), existing)
            self.assertEqual(existing.read_text(encoding="utf-8"), "正在填写的页面")

    def test_output_directory_error_then_retry(self):
        with TemporaryDirectory() as folder:
            blocked = Path(folder) / "不可作为目录"
            blocked.write_text("已有文件", encoding="utf-8")
            with self.assertRaises(OSError):
                self.start(blocked, no_open=True)
            self.assertEqual(blocked.read_text(encoding="utf-8"), "已有文件")
            self.assertTrue(Path(self.start(Path(folder) / "可用目录", no_open=True)["html_path"]).is_file())

    def test_posix_browser_paths_use_encoded_file_uri(self):
        import open_form
        # Windows 上模拟 macOS/Linux 路径对象；并非这些系统的实机验证。
        for location in ("/Users/demo/问卷 空格/page.html", "/home/demo/问卷 空格/page.html"):
            with self.subTest(location=location):
                page = Mock()
                page.resolve.return_value = page
                page.is_file.return_value = True
                page.as_uri.return_value = PurePosixPath(location).as_uri()
                opener = Mock(return_value=True)
                with patch.object(open_form, "Path", return_value=page):
                    self.assertTrue(open_form.open_form(location, opener=opener))
                opener.assert_called_once_with(PurePosixPath(location).as_uri(), new=2)
                self.assertNotIn(" ", opener.call_args.args[0])


if __name__ == "__main__":
    unittest.main()
