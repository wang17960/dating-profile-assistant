/* 验证选择、分支和本地复制，不向真实对话发送消息。 */
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {model, questions} = require("./helpers.cjs");
const state = (prefill = {}) => model.createState({questions, prefill});
const array = (value) => Array.from(value);

test("快速 15 题、标准 39 题，目标不同会调整问题", () => {
  assert.equal(model.plan(state()).length, 15);
  assert.equal(model.plan(state({mode: "standard"})).length, 39);
  assert.equal(model.plan(state({goal: "preferences"})).length, 4);
  assert.ok(!array(model.plan(state({goal: "profile"}))).includes("q86"));
});

test("已知资料不重问，仍保留原答案和公开范围", () => {
  const s = state({answers: {q02: {value: "29岁"}, q03: {value: "长春", disclosure: "public"}}});
  assert.ok(!array(model.plan(s)).includes("q02"));
  assert.equal(model.payload(s).answers.length, 2);
  assert.equal(s.answers.q02.disclosure, "analysis_only");
  assert.equal(s.answers.q03.disclosure, "public");
});

test("性格不确定会出现情景分支，改变答案后分支退出", () => {
  const s = state();
  model.answer(s, "q33", {status: "uncertain"});
  for (const id of ["q38", "q39", "q40"]) assert.ok(array(model.plan(s)).includes(id));
  model.answer(s, "q33", {value: ["慢热"]});
  assert.ok(!array(model.plan(s)).includes("q38"));
});

test("择偶不确定触发反向筛选；程度表等待具体选择", () => {
  const s = state({goal: "preferences"});
  model.answer(s, "q75", {status: "uncertain"});
  assert.ok(array(model.plan(s)).includes("q78"));
  assert.ok(!array(model.plan(s)).includes("q79"));
  model.answer(s, "q78", {value: ["长期失联"]});
  assert.ok(array(model.plan(s)).includes("q79"));
});

test("跳过和拒答清除值与公开授权，高透明不自动授权其他题", () => {
  const s = state();
  model.answer(s, "q08", {value: "敏感资料"});
  model.answer(s, "q89", {value: "高透明"});
  assert.equal(s.answers.q08.disclosure, "analysis_only");
  model.answer(s, "q08", {status: "declined", value: "不应传出", disclosure: "public"});
  assert.equal(s.answers.q08.value, null);
  assert.equal(s.answers.q08.disclosure, "analysis_only");
});

test("推断预填被拒绝；文字与对象答案可回传", () => {
  assert.throws(() => state({answers: {q33: {value: "回避型", source: "INFERENCE"}}}), /推断/);
  const s = state();
  model.answer(s, "q78", {value: ["长期失联"]});
  model.answer(s, "q79", {value: {[s.answers.q78.value[0]]: "完全不能接受"}});
  assert.equal(s.answers.q79.status, "answered");
  assert.ok(JSON.parse(model.prompt(s).split("DATING_FORM_V1\n")[1]).answers.some((a) => a.id === "q79"));
});

test("本地复制提示不依赖宿主接口，完整传递目标与答案", () => {
  const s = state({goal: "full"});
  model.answer(s, "q29", {value: ["跑步", "摄影"], note: "周末喜欢走走", disclosure: "public"});
  const result = model.prompt(s);
  const data = JSON.parse(result.split("DATING_FORM_V1\n")[1]);
  assert.equal(data.goal, "full");
  assert.deepEqual(data.answers[0].value, ["跑步", "摄影"]);
  assert.equal(data.answers[0].disclosure, "public");
  assert.ok(result.includes("dating-profile-assistant"));
  assert.ok(!result.includes("$dating-profile-assistant"));
});

test("本地手动复制流程提供结构化文本且没有宿主发送依赖", () => {
  const s = state();
  const prompt = model.prompt(s);
  const ui = fs.readFileSync(path.join(__dirname, "../assets/form-ui.js"), "utf8");
  assert.ok(prompt.includes("DATING_FORM_V1"));
  assert.ok(ui.includes("model.copyPrompt(state, navigator.clipboard"));
  assert.equal(typeof model.copyPrompt, "function");
  assert.ok(!ui.includes("sendFollowUpMessage"));
  assert.ok(!("submit" in model));
});

test("剪贴板拒绝时返回完整文本并触发手动复制备用区", async () => {
  const s = state();
  model.answer(s, "q02", {value: "29岁"});
  const expected = model.prompt(s);
  let fallback = "";
  const result = await model.copyPrompt(s, {writeText: async () => {throw new Error("clipboard denied");}},
    (text) => {fallback = text;});
  assert.equal(result.copied, false);
  assert.equal(result.text, expected);
  assert.equal(fallback, expected);
  assert.equal(s.answers.q02.value, "29岁");
});

test("汇总表全选只公开已回答的个人资料，全部不选保留答案", () => {
  const s = state({answers: {q02: {value: "29岁"}}});
  model.answer(s, "q29", {value: ["跑步"], note: "周末", source: "SELF_REPORT"});
  model.answer(s, "q33", {status: "uncertain"});
  model.answer(s, "q41", {status: "declined"});
  model.answer(s, "q86", {value: "自然"});
  model.setAllDisclosures(s, true);
  for (const id of ["q02", "q29"]) assert.equal(s.answers[id].disclosure, "public");
  for (const id of ["q33", "q41", "q86"]) assert.equal(s.answers[id].disclosure, "analysis_only");
  assert.equal(model.canDisclose(s, "q03"), false);
  assert.equal(model.canDisclose(s, "missing"), false);
  model.setAllDisclosures(s, false);
  assert.ok(Object.values(s.answers).every((answer) => answer.disclosure === "analysis_only"));
  assert.equal(s.answers.q02.value, "29岁");
  assert.deepEqual(array(s.answers.q29.value), ["跑步"]);
  assert.equal(s.answers.q29.note, "周末");
  assert.equal(s.answers.q29.source, "SELF_REPORT");
});

test("全选后单题可取消，修改回答保留授权，拒答清除授权", () => {
  const s = state({answers: {q02: {value: "29岁"}, q03: {value: "长春"}}});
  model.setAllDisclosures(s, true);
  model.setDisclosure(s, "q03", false);
  model.answer(s, "q02", {value: "30岁", disclosure: s.answers.q02.disclosure});
  assert.equal(s.answers.q02.disclosure, "public");
  assert.equal(s.answers.q03.disclosure, "analysis_only");
  model.answer(s, "q02", {status: "declined", disclosure: s.answers.q02.disclosure});
  model.setDisclosure(s, "q02", true);
  assert.equal(s.answers.q02.disclosure, "analysis_only");
  model.setDisclosure(s, "missing", true);
  assert.equal(s.answers.missing, undefined);
});

test("简答题旧补充合并到主输入框，不丢失或重复回传", () => {
  const s = state({answers: {q03: {value: "长春", note: "未来可以迁居", disclosure: "public"}}});
  const value = model.textAnswerValue(s.answers.q03);
  assert.equal(value, "长春；未来可以迁居");
  assert.equal(model.textAnswerValue({note: "只有补充"}), "只有补充");
  assert.equal(model.textAnswerValue(), "");
  model.answer(s, "q03", {value, note: "", disclosure: s.answers.q03.disclosure});
  assert.equal(model.payload(s).answers[0].value, value);
  assert.equal(model.payload(s).answers[0].note, "");
});

test("汇总授权集成：批量、单题和再次清空准确保留在复制文本", () => {
  const s = state({answers: {q02: {value: "29岁"}, q03: {value: "长春"}, q86: {value: "自然"}}});
  model.setAllDisclosures(s, true);
  model.setDisclosure(s, "q03", false);
  const first = JSON.parse(model.prompt(s).split("DATING_FORM_V1\n")[1]);
  assert.deepEqual(first.answers.map((answer) => answer.disclosure), ["public", "analysis_only", "analysis_only"]);
  model.setAllDisclosures(s, false);
  const second = JSON.parse(model.prompt(s).split("DATING_FORM_V1\n")[1]);
  assert.ok(second.answers.every((answer) => answer.disclosure === "analysis_only"));
});

test("旧平台字符串转换为单项选择", () => {
  const s = state({answers: {q86: {value: "小红书"}, q87: {value: ["真诚自然", "松弛轻松"]}}});
  const answers = Object.fromEntries(model.payload(s).answers.map((answer) => [answer.id, answer.value]));
  assert.deepEqual(array(answers.q86), ["小红书"]);
  assert.deepEqual(array(answers.q87), ["真诚自然", "松弛轻松"]);
});

test("版本矩阵处理空选项和重复选项", () => {
  assert.deepEqual(JSON.parse(JSON.stringify(model.buildDraftVariants(["小红书", "豆瓣"], ["真诚自然", "松弛轻松", "温柔"]))), [
    {platform: "小红书", tone: "真诚自然"}, {platform: "小红书", tone: "松弛轻松"}, {platform: "小红书", tone: "温柔"},
    {platform: "豆瓣", tone: "真诚自然"}, {platform: "豆瓣", tone: "松弛轻松"}, {platform: "豆瓣", tone: "温柔"},
  ]);
  assert.deepEqual(array(model.buildDraftVariants([], ["真诚自然"])), []);
  assert.deepEqual(array(model.buildDraftVariants(["小红书"], [])), []);
  assert.equal(array(model.buildDraftVariants(["小红书", "小红书"], ["真诚自然", "真诚自然"])).length, 1);
  assert.match(model.prompt(state()), /只在当前对话追问未选的平台或语气/);
  assert.match(model.prompt(state()), /不重新打开问卷或重问个人资料/);
  assert.doesNotMatch(model.prompt(state({goal: "profile"})), /追问未选的平台或语气/);
});

test("复制提示明确平台和语气的分组组合", () => {
  const s = state();
  model.answer(s, "q86", {value: ["小红书", "豆瓣"]});
  model.answer(s, "q87", {value: ["真诚自然", "松弛轻松"]});
  const prompt = model.prompt(s);
  const data = JSON.parse(prompt.split("DATING_FORM_V1\n")[1]);
  assert.equal(data.draft_variants.length, 4);
  assert.deepEqual(JSON.parse(JSON.stringify(data.draft_variants)), [
    {platform: "小红书", tone: "真诚自然"}, {platform: "小红书", tone: "松弛轻松"},
    {platform: "豆瓣", tone: "真诚自然"}, {platform: "豆瓣", tone: "松弛轻松"},
  ]);
  assert.match(prompt, /按平台分组/);
  assert.match(prompt, /每种语气单独生成/);
  assert.match(prompt, /不重新启动问卷/);
});

test("批量公开授权排除写作偏好", () => {
  const s = state({answers: {q86: {value: "小红书"}, q87: {value: ["真诚自然"]}}});
  model.setAllDisclosures(s, true);
  assert.equal(s.answers.q86.disclosure, "analysis_only");
  assert.equal(s.answers.q87.disclosure, "analysis_only");
});
