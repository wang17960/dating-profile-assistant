/* 使用现有 Playwright 与系统浏览器验证本地问卷；不安装框架、不发送聊天。 */
const {test, before, after} = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const {pathToFileURL} = require("node:url");
const {execFileSync} = require("node:child_process");
const {root, python} = require("./helpers.cjs");
const bundledModule = path.join(os.homedir(), ".cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");
const {chromium} = require(process.env.PLAYWRIGHT_MODULE || (fs.existsSync(bundledModule) ? bundledModule : "playwright"));
const channel = process.env.BROWSER_CHANNEL || "msedge";
const output = path.resolve(root, "../output/playwright", channel);
let browser;

before(async () => {
  fs.mkdirSync(output, {recursive: true});
  browser = await chromium.launch({headless: true, channel});
});
after(async () => {await browser?.close();});

async function open(t, prefill = {}, width = 1280, clipboard = "denied") {
  const filename = path.join(output, `${t.name.slice(0, 8)}-${width}.html`);
  const html = execFileSync(python, ["-c",
    "import json,sys; sys.path.insert(0,sys.argv[1]); import build_form; print(build_form.render_form(json.load(sys.stdin)))",
    path.join(root, "scripts")], {input: JSON.stringify(prefill), encoding: "utf8", env: {...process.env, PYTHONIOENCODING: "utf-8"}});
  fs.writeFileSync(filename, html, "utf8");
  const context = await browser.newContext({viewport: {width, height: 900}});
  const page = await context.newPage();
  page.setDefaultTimeout(8000);
  const errors = [], network = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.route(/^https?:/, (route) => {network.push(route.request().url()); return route.abort();});
  await page.addInitScript((mode) => {
    Object.defineProperty(navigator, "clipboard", {value: {writeText: async (text) => {
      if (mode === "denied") throw new Error("合成的剪贴板拒绝");
      window.testCopiedText = text;
    }}, configurable: true});
  }, clipboard);
  await page.goto(pathToFileURL(filename).href);
  t.after(async () => {
    assert.deepEqual(errors, [], "页面不能有未处理的脚本错误");
    assert.deepEqual(network, [], "问卷不能发送网络请求");
    await context.close();
  });
  return page;
}

const answer = (value, disclosure = "analysis_only", extra = {}) => ({value, disclosure, ...extra});
const parse = (text) => JSON.parse(text.split("DATING_FORM_V1\n")[1]);

for (const width of [1280, 320]) {
  test(`完整引导${width}：开始、提前核对、补选写作参数与复制回原对话`, async (t) => {
    const page = await open(t, {}, width, "success");
    assert.equal(await page.locator('[data-flow-step][aria-current="step"]').count(), 1);
    await page.locator("[data-begin]").click();
    await page.locator('[data-question-id="q02"] input[type=text]').fill("29岁");
    await page.locator("[data-next]").click();
    await page.locator("[data-back]").click();
    assert.equal(await page.locator('[data-question-id="q02"] input[type=text]').inputValue(), "29岁");
    await page.locator("[data-review-now]").click();
    assert.match(await page.locator("[data-writing-summary]").innerText(), /未选择/);
    await page.locator("[data-edit-writing]").click();
    assert.equal(await page.locator("[data-question-id]").count(), 3);
    await page.locator('[data-question-id="q86"]').getByLabel("豆瓣", {exact: true}).check();
    await page.locator('[data-question-id="q87"]').getByLabel("真诚自然", {exact: true}).check();
    await page.locator('[data-question-id="q88"]').getByLabel("短", {exact: true}).check();
    await page.locator("[data-next]").click();
    assert.match(await page.locator("[data-writing-summary]").innerText(), /豆瓣/);
    await page.locator('[data-disclosure-id="q02"]').check();
    await page.getByRole("button", {name: "复制答案", exact: true}).click();
    assert.equal(await page.locator("[data-handoff]").isVisible(), true);
    assert.match(await page.locator("[data-handoff]").innerText(), /粘贴并发送/);
    assert.equal(await page.locator('[data-flow-step="handoff"][aria-current="step"]').count(), 1);
    const payload = parse(await page.evaluate(() => window.testCopiedText));
    assert.equal(payload.draft_variants.length, 1);
    assert.equal(payload.answers.find((a) => a.id === "q02").disclosure, "public");
    await page.screenshot({path: path.join(output, `flow-${width}.png`), fullPage: true});
    await page.locator('[data-disclosure-id="q02"]').uncheck();
    assert.equal(await page.locator("[data-handoff]").isVisible(), false);
    assert.equal(await page.getByRole("button", {name: "复制答案", exact: true}).isEnabled(), true);
  });
}

test("不要求写作参数的目标隐藏补选，缺少参数也能复制完整数据", async (t) => {
  const page = await open(t, {goal: "report", mode: "standard", answers: {q02: answer("29岁")}});
  assert.equal(await page.locator("[data-goal]").inputValue(), "report");
  assert.equal(await page.locator("[data-mode]").inputValue(), "standard");
  await page.locator("[data-known]").click();
  assert.equal(await page.locator("[data-writing-panel]").isVisible(), false);
  await page.locator("[data-submit]").click();
  assert.equal(parse(await page.locator("[data-copy-text]").inputValue()).draft_variants.length, 0);
  assert.equal(await page.locator("[data-handoff]").isVisible(), true);
  await page.locator("[data-continue]").click();
  await page.locator("[data-settings]").click();
  await page.locator("[data-goal]").selectOption("post");
  await page.locator("[data-known]").click();
  assert.equal(await page.locator("[data-writing-panel]").isVisible(), true);
  await page.locator("[data-submit]").click();
  assert.equal(parse(await page.locator("[data-copy-text]").inputValue()).draft_variants.length, 0);
});

test("误打开原始模板时显示说明并禁用控件，不产生占位符脚本错误", async (t) => {
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  t.after(async () => {await context.close();});
  await page.goto(pathToFileURL(path.join(root, "assets/form-shell.html")).href);
  assert.equal(await page.locator("[data-template-warning]").isVisible(), true);
  assert.match(await page.locator("[data-template-warning]").innerText(), /生成的问卷/);
  assert.equal(await page.locator("[data-begin]").isDisabled(), true);
  assert.deepEqual(errors, []);
});

test("完整问卷开始后呈现问题，继续和返回可正常使用", async (t) => {
  const page = await open(t);
  assert.equal(await page.locator("[data-template-warning]").isVisible(), false);
  await page.getByRole("button", {name: "开始填写"}).click();
  assert.equal(await page.locator("[data-start]").isVisible(), false);
  assert.equal(await page.locator("[data-question-view]").isVisible(), true);
  assert.equal(await page.locator("[data-question-id]").count(), 5);
  const first = await page.locator("[data-question-id]").first().getAttribute("data-question-id");
  await page.locator("[data-next]").click();
  assert.notEqual(await page.locator("[data-question-id]").first().getAttribute("data-question-id"), first);
  await page.locator("[data-back]").click();
  assert.equal(await page.locator("[data-question-id]").first().getAttribute("data-question-id"), first);
});

for (const width of [1280, 320]) {
  test(`桌面与窄屏${width}：规则、六组合和复制失败后的授权修改`, async (t) => {
    const page = await open(t, {answers: {q02: answer("29岁"), q06: answer("合成公司"),
      q08: answer(["只供分析"], "analysis_only", {note: "合成财务数字"}), q10: answer(["工作信息"]),
      q86: answer(["豆瓣", "朋友圈"]), q87: answer(["真诚自然", "务实直接", "温柔"])}}, width);
    await page.locator("[data-known]").click();
    await page.locator("[data-select-all]").click();
    assert.equal(await page.locator('[data-disclosure-id="q02"]').isChecked(), true);
    for (const id of ["q06", "q08", "q10", "q86", "q87"]) assert.equal(await page.locator(`[data-disclosure-id="${id}"]`).isDisabled(), true);
    assert.match(await page.locator("[data-variants]").innerText(), /共 6 版/);
    await page.locator("[data-submit]").click();
    assert.equal(await page.locator("[data-copy-text]").isVisible(), true);
    let payload = parse(await page.locator("[data-copy-text]").inputValue());
    assert.equal(payload.answers.find((a) => a.id === "q06").disclosure, "analysis_only");
    assert.equal(payload.draft_variants.length, 6);
    await page.locator('[data-disclosure-id="q02"]').uncheck();
    assert.equal(await page.locator("[data-copy-text]").inputValue(), "");
    assert.equal(await page.locator("[data-copy-text]").isVisible(), false);
    assert.match(await page.locator("[data-status]").innerText(), /重新复制/);
    await page.locator("[data-submit]").click();
    payload = parse(await page.locator("[data-copy-text]").inputValue());
    assert.equal(payload.answers.find((a) => a.id === "q02").disclosure, "analysis_only");
    assert.equal(await page.locator("[data-submit]").isEnabled(), true);
    const sizes = await page.evaluate(() => ({page: document.documentElement.scrollWidth, viewport: innerWidth,
      table: document.querySelector(".table-responsive").clientWidth,
      scroll: document.querySelector(".table-responsive").scrollWidth}));
    assert.ok(sizes.page <= sizes.viewport + 1, JSON.stringify(sizes));
    if (width === 320) {
      assert.ok(sizes.scroll <= sizes.table + 1, "窄屏汇总按题分块，不需要横向滚动");
      const row = page.locator('[data-disclosure-id="q02"]').locator("xpath=ancestor::tr");
      assert.match(await row.innerText(), /年龄或年龄段/);
      assert.ok((await row.boundingBox()).width <= sizes.viewport);
    }
    await page.screenshot({path: path.join(output, `review-${width}.png`), fullPage: true});
  });
}

test("复制成功后修改答案、拒答与恢复不会沿用旧授权", async (t) => {
  const page = await open(t, {answers: {q02: answer("29岁", "public")}}, 1280, "success");
  await page.locator("[data-known]").click();
  await page.locator("[data-submit]").click();
  assert.match(await page.locator("[data-status]").innerText(), /答案已复制/);
  await page.locator('[data-disclosure-id="q02"]').locator("xpath=ancestor::tr").getByRole("button", {name: "修改"}).click();
  const block = page.locator('[data-question-id="q02"]');
  await block.getByLabel("这题的状态").selectOption("declined");
  assert.match(await page.locator("[data-status]").innerText(), /重新复制/);
  await block.getByLabel("这题的状态").selectOption("answered");
  await block.locator("input[type=text]").fill("30岁");
  await page.locator("[data-next]").click();
  assert.equal(await page.locator('[data-disclosure-id="q02"]').isChecked(), false);
  await page.locator("[data-submit]").click();
  const payload = parse(await page.evaluate(() => window.testCopiedText));
  assert.equal(payload.answers[0].value, "30岁");
  assert.equal(payload.answers[0].disclosure, "analysis_only");
});

test("父题改选后子题恢复填写，撤回后旧评分不回传", async (t) => {
  const page = await open(t, {goal: "preferences", answers: {q75: answer(null, "analysis_only", {status: "uncertain"}),
    q78: answer(["长期失联"]), q79: answer({"长期失联": "完全不能接受"}, "public")}});
  await page.locator("[data-known]").click();
  await page.locator('[data-disclosure-id="q78"]').locator("xpath=ancestor::tr").getByRole("button", {name: "修改"}).click();
  await page.locator('[data-question-id="q78"]').getByLabel("这题的状态").selectOption("declined");
  await page.locator("[data-next]").click();
  assert.equal(await page.locator('[data-disclosure-id="q79"]').isDisabled(), true);
  await page.locator("[data-submit]").click();
  let body = parse(await page.locator("[data-copy-text]").inputValue());
  assert.equal(body.answers.find((a) => a.id === "q79").status, "skipped");
  await page.locator('[data-disclosure-id="q78"]').locator("xpath=ancestor::tr").getByRole("button", {name: "修改"}).click();
  await page.locator('[data-question-id="q78"]').getByLabel("这题的状态").selectOption("answered");
  await page.locator('[data-question-id="q78"] input[type=checkbox]').first().check();
  await page.locator("[data-next]").click();
  await page.locator('[data-disclosure-id="q79"]').locator("xpath=ancestor::tr").getByRole("button", {name: "修改"}).click();
  assert.equal(await page.locator('[data-question-id="q79"] select').count(), 2);
});

test("键盘操作、每步题数与依据类型可正常回传", async (t) => {
  const page = await open(t);
  await page.keyboard.press("Tab");
  assert.equal(await page.locator("[data-goal]").evaluate((e) => e === document.activeElement), true);
  await page.locator("[data-goal]").selectOption("report");
  await page.locator("[data-begin]").click();
  assert.ok(await page.locator("[data-question-id]").count() <= 5);
  const q37 = page.locator('[data-question-id="q37"]');
  await q37.locator("textarea").fill("我希望未来有分歧时主动再谈");
  await q37.getByLabel("这段回答主要来自").selectOption("preference");
  await page.locator("[data-review-now]").click();
  await page.locator("[data-submit]").click();
  const body = parse(await page.locator("[data-copy-text]").inputValue());
  assert.equal(body.answers.find((a) => a.id === "q37").evidence, "preference");
  assert.equal(body.goal, "report");
});

test("超长资料提交出错后仍可修改并重新复制", async (t) => {
  const page = await open(t, {answers: {q02: answer("x".repeat(66000))}});
  await page.locator("[data-known]").click();
  await page.locator("[data-submit]").click();
  assert.equal(await page.locator("[data-error]").isVisible(), true);
  assert.equal(await page.locator("[data-submit]").isEnabled(), true);
  await page.locator('[data-disclosure-id="q02"]').locator("xpath=ancestor::tr").getByRole("button", {name: "修改"}).click();
  await page.locator('[data-question-id="q02"] input[type=text]').fill("29岁");
  await page.locator("[data-next]").click();
  await page.locator("[data-submit]").click();
  assert.equal(await page.locator("[data-error]").isVisible(), false);
  assert.equal(parse(await page.locator("[data-copy-text]").inputValue()).answers[0].value, "29岁");
});

for (const clipboard of ["success", "denied"]) {
  test(`复制后直接跳过新题使旧回传失效：${clipboard}`, async (t) => {
    const page = await open(t, {answers: {q02: answer("29岁")}}, 1280, clipboard);
    await page.locator("[data-known]").click();
    await page.locator("[data-submit]").click();
    assert.equal(await page.locator("[data-handoff]").isVisible(), true);
    await page.locator("[data-continue]").click();
    // 不触碰输入框，仅浏览未填题后提前核对，也会产生需要回传的跳过记录。
    await page.locator("[data-review-now]").click();
    assert.equal(await page.locator("[data-handoff]").isVisible(), false);
    assert.equal(await page.locator("[data-copy-text]").isVisible(), false);
    assert.equal(await page.locator("[data-copy-text]").inputValue(), "");
    assert.match(await page.locator("[data-status]").innerText(), /重新复制/);
    await page.locator("[data-submit]").click();
    const text = clipboard === "success" ? await page.evaluate(() => window.testCopiedText)
      : await page.locator("[data-copy-text]").inputValue();
    const body = parse(text);
    assert.ok(body.answers.length > 1);
    assert.ok(body.answers.some((a) => a.status === "skipped"));
    assert.equal(body.answers.find((a) => a.id === "q02").value, "29岁");
    assert.equal(await page.locator("[data-handoff]").isVisible(), true);
  });
}