"""题库构建与数据嵌入检查；不调用模型或发送真实聊天。"""

import importlib.util
import json
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("build_form", ROOT / "scripts/build_form.py")
BUILDER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BUILDER)


class FormBuilderTests(unittest.TestCase):
    def test_canonical_question_bank_and_group_choices(self):
        questions = BUILDER.load_questions()
        self.assertEqual(len(questions), 89)
        self.assertEqual(len({q["id"] for q in questions}), 89)
        interests = next(q for q in questions if q["id"] == "q29")
        self.assertGreater(len(interests["options"]), 50)
        self.assertEqual(len(interests["groups"]), 6)
        self.assertIn("慢热", next(q for q in questions if q["id"] == "q33")["options"])

    def test_platform_and_tone_questions_are_multi(self):
        questions = BUILDER.load_questions()
        platform = next(q for q in questions if q["id"] == "q86")
        tone = next(q for q in questions if q["id"] == "q87")
        self.assertEqual(platform["type"], "multi")
        self.assertEqual(tone["type"], "multi")
        self.assertEqual(platform["options"], ["小红书", "豆瓣", "微博", "抖音图文", "朋友圈", "相亲群", "通用"])
        self.assertEqual(tone["options"], ["真诚自然", "务实直接", "松弛轻松", "风趣", "温柔", "文艺", "信息密集", "极简", "成熟", "自嘲"])

    def test_prefill_multichoice_is_limited_to_known_options(self):
        fragment = BUILDER.render_form({"answers": {
            "q86": {"value": ["小红书", "不是平台", "豆瓣", "小红书"]},
            "q87": {"value": "真诚自然"},
        }})
        embedded = re.search(r'<script type="application/json"[^>]*>(.*?)</script>', fragment, re.S)[1]
        data = json.loads(embedded)
        self.assertEqual(data["prefill"]["answers"]["q86"]["value"], ["小红书", "豆瓣"])
        self.assertEqual(data["prefill"]["answers"]["q87"]["value"], ["真诚自然"])

    def test_prefill_survives_html_without_running_markup(self):
        value = '</script><img src=x onerror="alert(1)">'
        fragment = BUILDER.render_form({"answers": {"q06": {"value": value}}})
        embedded = re.search(r'<script type="application/json"[^>]*>(.*?)</script>', fragment, re.S)[1]
        self.assertNotIn("</script>", embedded)
        data = json.loads(embedded)
        self.assertEqual(data["prefill"]["answers"]["q06"]["value"], value)
        self.assertNotIn("__ROOT_ID__", fragment)
        self.assertNotIn("__MODEL__", fragment)
        self.assertNotIn("__UI__", fragment)
        self.assertLess(len(fragment.encode()), 1_000_000)

    def test_inference_cannot_be_prefilled_as_user_fact(self):
        with self.assertRaisesRegex(ValueError, "推断"):
            BUILDER.render_form({"answers": {"q33": {"value": "回避型", "source": "INFERENCE"}}})

    def test_invalid_prefill_rejected(self):
        for prefill in [{"answers": {"q999": {"value": "x"}}},
                        {"answers": {"q02": {"status": "diagnosed"}}},
                        {"mode": "other"}, {"goal": "unknown"}]:
            with self.subTest(prefill=prefill), self.assertRaises(ValueError):
                BUILDER.render_form(prefill)

    def test_prefill_types_are_checked_before_rendering(self):
        cases = [{"answers": []}, {"focus": 123}, {"focus": ["unknown"]},
                 {"answers": {"q02": {"value": 12}}},
                 {"answers": {"q02": {"note": []}}},
                 {"answers": {"q53": {"evidence": "diagnosis"}}},
                 {"answers": {"q29": {"value": ["跑步", {}]}}},
                 {"mode": []}, {"goal": {}},
                 *[{"answers": {"q02": {field: []}}}
                   for field in ["source", "evidence", "disclosure", "status"]]]
        for prefill in cases:
            with self.subTest(prefill=prefill), self.assertRaises(ValueError):
                BUILDER.render_form(prefill)

    def test_user_text_equal_to_template_tokens_remains_data(self):
        for value in ["__MODEL__", "__UI__", "__ROOT_ID__", "__DATA__"]:
            with self.subTest(value=value):
                fragment = BUILDER.render_form({"answers": {"q06": {"value": value}}})
                embedded = re.search(r'<script type="application/json"[^>]*>(.*?)</script>', fragment, re.S)[1]
                self.assertEqual(json.loads(embedded)["prefill"]["answers"]["q06"]["value"], value)

    def test_output_is_standalone_html_with_manual_copy_only(self):
        document = BUILDER.render_form()
        self.assertIn("<!doctype html>", document.lower())
        self.assertIn('<meta charset="utf-8">', document.lower())
        self.assertIn("data-copy-text", document)
        self.assertIn("model.copyPrompt(state, navigator.clipboard", document)
        self.assertIn("clipboard.writeText(text)", document)
        self.assertNotIn("sendFollowUpMessage", document)
        self.assertNotIn("window.openai", document)
        self.assertNotIn("fetch(", document)
        self.assertNotIn("localStorage", document)
        self.assertNotIn("document.cookie", document)

    def test_template_and_generated_form_have_explicit_entry_guard(self):
        template = (ROOT / "assets/form-shell.html").read_text(encoding="utf-8")
        self.assertIn("data-template-warning", template)
        self.assertNotIn("python scripts/build_form.py", template)
        self.assertIn("使用 dating-profile-assistant", template)
        self.assertIn("control.disabled = true", template)
        document = BUILDER.render_form()
        for token in ["__MODEL__", "__UI__", "__DATA__", "__ROOT_ID__"]:
            self.assertNotIn(token, document)

    def test_open_form_reports_missing_file_and_browser_failure(self):
        opener_path = ROOT / "scripts/open_form.py"
        self.assertTrue(opener_path.is_file(), "应提供本地默认浏览器启动器")
        spec = importlib.util.spec_from_file_location("open_form", opener_path)
        opener_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(opener_module)
        with self.subTest("missing file"):
            self.assertFalse(opener_module.open_form(ROOT / "missing.html", opener=lambda *_args, **_kwargs: True))
        with self.subTest("browser rejects"):
            from tempfile import TemporaryDirectory
            with TemporaryDirectory() as folder:
                page = Path(folder) / "form.html"
                page.write_text("ok", encoding="utf-8")
                opened = []
                result = opener_module.open_form(page, opener=lambda uri, **_kwargs: opened.append(uri) or False)
                self.assertFalse(result)
                self.assertEqual(len(opened), 1)

    def test_output_contains_manual_copy_flow_without_host_bridge(self):
        document = BUILDER.render_form()
        self.assertIn("复制答案", document)
        self.assertIn("data-copy-text", document)
        self.assertIn("完整答案已显示并选中", document)
        self.assertIn("model.copyPrompt(state, navigator.clipboard", document)
        self.assertNotIn("sendFollowUpMessage", document)

    def test_standalone_styles_support_narrow_screens_and_table_scrolling(self):
        document = BUILDER.render_form()
        self.assertIn("@media (max-width: 560px)", document)
        self.assertIn(".form-actions { display: flex; flex-wrap: wrap", document)
        self.assertIn(".table-responsive { width: 100%; overflow-x: auto;", document)
        self.assertIn(".viz-controls { grid-template-columns: 1fr;", document)

    def test_summary_consent_controls_embedded(self):
        fragment = BUILDER.render_form()
        self.assertIn("data-select-all>全选", fragment)
        self.assertIn("data-select-none>全部不选", fragment)
        self.assertIn('"table table-sm review-table"', fragment)
        self.assertNotIn("允许这题的信息写入相亲帖", fragment)
        self.assertIn('if (q.type !== "text")', fragment)

    def test_skill_entry_and_relative_links(self):
        entry = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        metadata = re.match(r"\A---\s*\n(.*?)\n---", entry, re.S)
        self.assertIsNotNone(metadata)
        self.assertRegex(metadata[1], r"(?m)^name: dating-profile-assistant$")
        self.assertRegex(metadata[1], r"(?m)^description: .+")
        interface = (ROOT / "agents/openai.yaml").read_text(encoding="utf-8")
        self.assertIn("$dating-profile-assistant", interface)
        self.assertIn("粘贴并发送", interface)
        for document in ROOT.rglob("*.md"):
            for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", document.read_text(encoding="utf-8")):
                if re.match(r"[a-z]+://", target) or target.startswith("#"):
                    continue
                with self.subTest(document=document.name, target=target):
                    self.assertTrue((document.parent / target.split("#")[0]).exists())


if __name__ == "__main__":
    unittest.main()
