/* 真实题库驱动的协议、取题和授权回归。 */
const test = require("node:test");
const assert = require("node:assert/strict");
const {model, questions, plain} = require("./helpers.cjs");
const state = (prefill = {}) => model.createState({questions, prefill});
const get = (s, id) => model.payload(s).answers.find((a) => a.id === id);

test("公开规则不参与全选，明确排除范围优先于个人资料授权", () => {
  const s = state({answers: {q06: {value: "某公司工程师", disclosure: "public"},
    q08: {value: ["只供分析"], note: "合成财务资料"}, q10: {value: ["工作信息"]}}});
  model.setAllDisclosures(s, true);
  for (const id of ["q06", "q08", "q10"]) assert.equal(get(s, id).disclosure, "analysis_only");
  assert.equal(get(s, "q08").kind, "privacy_rule");
  assert.ok(model.payload(s).privacy_constraints.blocked_ids.includes("q06"));
  model.answer(s, "q10", {status: "skipped"});
  assert.equal(get(s, "q06").disclosure, "analysis_only", "解除限制不能恢复旧授权");
  model.setDisclosure(s, "q06", true);
  assert.equal(get(s, "q06").disclosure, "public");
});

test("旧文字公开限制保留，并收窄未核对的公开授权", () => {
  const s = state({answers: {q10: {value: "公司和收入都不要公开"},
    q06: {value: "合成公司", disclosure: "public"}, q02: {value: "29岁"}}});
  model.setAllDisclosures(s, true);
  assert.ok(model.payload(s).privacy_constraints.requires_review);
  assert.match(get(s, "q10").note, /公司和收入/);
  assert.ok(model.payload(s).answers.every((a) => a.disclosure === "analysis_only"));
});

test("撤回父题后评分回传为撤回状态，不复活旧事实和授权", () => {
  const s = state();
  model.answer(s, "q78", {value: ["长期失联"]});
  const selected = s.answers.q78.value[0];
  model.answer(s, "q79", {value: {[selected]: "完全不能接受"}, disclosure: "public"});
  assert.equal(get(s, "q79").status, "answered");
  assert.equal(get(s, "q79").disclosure, "public");
  model.answer(s, "q78", {status: "declined"});
  assert.equal(get(s, "q79").status, "skipped");
  assert.equal(get(s, "q79").value, null);
  assert.equal(get(s, "q79").disclosure, "analysis_only");
  assert.ok(!model.plan(s).includes("q79"));
});

test("父题缩减、预填与回传统一清除失效的评分和补充", () => {
  const opts = questions.find((q) => q.id === "q78").options.slice(0, 2);
  const s = state({answers: {q78: {value: opts}, q79: {value: {
    [opts[0]]: "完全不能接受", [opts[1]]: "无所谓", "不存在的选项": "无所谓"}, note: "旧补充", disclosure: "public"}}});
  assert.equal(Object.keys(get(s, "q79").value).length, 2);
  model.answer(s, "q78", {value: [opts[1]]});
  assert.deepEqual(plain(get(s, "q79").value), {[opts[1]]: "无所谓"});
  assert.equal(get(s, "q79").note, "");
  assert.equal(get(s, "q79").disclosure, "analysis_only");
});

test("快速写帖采集具体原话，快速报告采集关系证据，目标取题有区别", () => {
  const post = model.plan(state());
  const report = model.plan(state({goal: "report"}));
  assert.ok(post.includes("q84"));
  for (const id of ["q41", "q51", "q52", "q53", "q56", "q61", "q62"]) assert.ok(report.includes(id), id);
  assert.ok(!report.includes("q86"));
  assert.notDeepEqual(plain(post), plain(report));
  assert.ok(post.length <= 20);
  assert.ok(model.plan(state({goal: "full"})).length <= 20);
});

test("深度模式只展开所选主题，保留公开规则与必要写作参数", () => {
  const ids = model.plan(state({goal: "report", mode: "deep", focus: ["self"]}));
  assert.ok(ids.includes("q37"));
  for (const id of ["q41", "q61", "q75", "q86"]) assert.ok(!ids.includes(id), id);
  const post = model.plan(state({mode: "deep", focus: ["values"]}));
  assert.ok(post.includes("q61"));
  assert.ok(post.includes("q86"));
  assert.ok(!post.includes("q52"));
});

test("依据类型与身份视角分开，不把理想偏好改成经历", () => {
  const s = state({answers: {q53: {value: "几小时后", evidence: "preference"}}});
  assert.equal(get(s, "q53").evidence, "preference");
  model.answer(s, "q53", {value: "第二天", evidence: "experience"});
  assert.equal(get(s, "q53").evidence, "experience");
});

test("7平台与10语气全部保留，明确预告70版并保持平台优先顺序", () => {
  const platforms = questions.find((q) => q.id === "q86").options;
  const tones = questions.find((q) => q.id === "q87").options;
  const s = state({answers: {q86: {value: platforms}, q87: {value: tones}}});
  assert.equal(model.variantSummary(s).count, 70);
  assert.equal(model.payload(s).draft_variants.length, 70);
  assert.deepEqual(plain(model.payload(s).draft_variants[10]), {platform: platforms[1], tone: tones[0]});
});

test("异常状态和未知题号在模型入口拒绝，写作参数不生成非帖目标版本", () => {
  assert.throws(() => model.answer(state(), "q02", {status: "bad", value: "x"}), /状态/);
  const s = state({goal: "profile", answers: {q86: {value: "小红书"}, q87: {value: "温柔"}}});
  assert.equal(model.payload(s).draft_variants.length, 0);
});
