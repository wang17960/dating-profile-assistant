"""分发包可重建且不包含原始帖子、预填文件与验证输出。"""

import json
import os
import subprocess
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import build_form
import package_skill


class PackageTests(unittest.TestCase):
    def test_zip_can_build_all_synthetic_fixtures_after_extracting(self):
        with TemporaryDirectory() as folder:
            base = Path(folder)
            result = package_skill.package_skill(base / "skill.zip")
            with ZipFile(result["path"]) as archive:
                names = archive.namelist()
                self.assertTrue(all(name.startswith("dating-profile-assistant/") for name in names))
                self.assertFalse(any("__pycache__" in name or "post_" in name or "output/" in name for name in names))
                archive.extractall(base / "extracted")
            extracted = base / "extracted/dating-profile-assistant"
            self.assertEqual(build_form.skill_version(extracted), result["version"])
            fixtures = json.loads((extracted / "tests/content-cases.json").read_text(encoding="utf-8"))
            self.assertTrue(fixtures["synthetic"])
            for case in fixtures["cases"]:
                with self.subTest(case=case["id"]):
                    document = build_form.render_form(case["prefill"], root=extracted)
                    self.assertIn("<!doctype html>", document.lower())
            launched = subprocess.run([sys.executable, str(extracted / "scripts/start_form.py"),
                                      "--output-dir", str(base / "搬迁 后输出"), "--no-open"],
                                     cwd=base, capture_output=True, encoding="utf-8", check=True,
                                     env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            data = json.loads(launched.stdout)
            document = Path(data["html_path"]).read_text(encoding="utf-8")
            self.assertIn(str(extracted.resolve()).replace("\\", "\\\\"), document)
            self.assertFalse(data["browser_opened"])

    def test_private_extra_files_are_not_collected(self):
        with TemporaryDirectory() as folder:
            base = Path(folder)
            for name in ["real-prefill.json", "questionnaire.html", "references/private-post.md",
                         "tests/__pycache__/test.pyc", "output/private.txt", "assets/private.json",
                         "tests/real-prefill.json", "scripts/private.py"]:
                item = base / name
                item.parent.mkdir(parents=True, exist_ok=True)
                item.write_text("不应分发的合成标记", encoding="utf-8")
            self.assertEqual(package_skill.collect_files(base), [])


if __name__ == "__main__":
    unittest.main()
