/* 本地网页问卷。用户点击复制后，自行粘贴到当前 AI 对话。 */
(function () {
  "use strict";
  const root = document.getElementById("__ROOT_ID__");
  const config = JSON.parse(document.getElementById("__ROOT_ID__-data").textContent);
  const model = globalThis.DatingForm;
  const state = model.createState(config);
  const find = (selector) => root.querySelector(selector);
  const questionMap = new Map(state.questions.map((q) => [q.id, q]));
  let history = [], page = -1, seen = new Set(), editing = false, busy = false;
  let copiedRevision = null;
  let currentView = "start";

  function updateFlow() {
    const active = currentView !== "review" ? "fill" : copiedRevision === state.revision ? "handoff" : "review";
    for (const step of root.querySelectorAll("[data-flow-step]")) {
      if (step.dataset.flowStep === active) step.setAttribute("aria-current", "step");
      else step.removeAttribute("aria-current");
    }
  }

  function updateVariantCount() {
    const variants = model.variantSummary(state);
    find("[data-variants]").hidden = !["post", "full"].includes(state.goal);
    find("[data-variants]").textContent = variants.count
      ? `已选 ${variants.platforms} 个平台 × ${variants.tones} 种语气，共 ${variants.count} 版；较多时按平台分批生成全部结果。`
      : "选择平台和语气后，这里会显示预计版本数。";
    find("[data-plan-hint]").textContent = `当前预计 ${model.plan(state).length} 个问题（含未回答的公开范围规则）；每题都可跳过，也可提前生成。`;
    const modes = {quick: "快速", standard: "标准", deep: "深度"};
    find("[data-start-help]").textContent = `当前目标：${model.goals[state.goal]}；${modes[state.mode]}模式。已有资料会保留，每步最多 5 题。`;
  }

  function invalidateCopy() {
    if (copiedRevision !== null) {
      find("[data-copy-text]").value = "";
      find("[data-copy-text]").hidden = true;
      find("[data-status]").textContent = "答案或公开范围已修改，请重新复制后再粘贴。";
      copiedRevision = null;
    }
    find("[data-handoff]").hidden = true;
    updateFlow();
    updateVariantCount();
  }

  function element(tag, text, className) {
    const item = document.createElement(tag);
    if (text !== undefined) item.textContent = text;
    if (className) item.className = className;
    return item;
  }

  function view(name) {
    currentView = name;
    find("[data-start]").hidden = name !== "start";
    find("[data-question-view]").hidden = name !== "questions";
    find("[data-review]").hidden = name !== "review";
    find("[data-error]").hidden = true;
    updateFlow();
  }

  function showError(error) {
    find("[data-error]").textContent = error.message || "提交未完成，请重试。";
    find("[data-error]").hidden = false;
  }

  function select(options, label, value) {
    const wrapper = element("label", label, "form-label");
    const input = element("select", undefined, "form-select");
    for (const [key, text] of options) {
      const option = element("option", text);
      option.value = key;
      input.append(option);
    }
    input.value = value || "";
    wrapper.append(input);
    return {wrapper, input};
  }

  function renderQuestion(q) {
    const saved = state.answers[q.id] || {status: "answered", value: "", disclosure: "analysis_only"};
    const block = element("div", undefined, "question");
    block.dataset.questionId = q.id;
    block.append(element("div", q.section, "section-label text-muted text-small"));
    block.append(element("label", q.display_label || q.label, "question-title form-label"));
    const fields = element("div");
    let valueControls = [], ratingControls = [];
    if (q.type === "text") {
      const compact = [2, 3, 4, 6, 11].includes(q.number);
      const input = element(compact ? "input" : "textarea", undefined, "form-control");
      if (compact) input.type = "text";
      else input.rows = 2;
      input.maxLength = 1200;
      input.setAttribute("aria-label", q.label);
      input.value = model.textAnswerValue(saved);
      fields.append(input);
      valueControls = [input];
    } else if (q.type === "rating") {
      const values = state.answers.q78?.value;
      for (const item of Array.isArray(values) ? values : []) {
        const control = select([["", "请选择接受程度"], ...q.options.map((v) => [v, v])], item, saved.value?.[item]);
        control.wrapper.classList.add("field-space");
        fields.append(control.wrapper);
        ratingControls.push([item, control.input]);
      }
    } else {
      const groups = q.groups || [{label: "", options: q.options}];
      for (const group of groups) {
        if (group.label) fields.append(element("div", group.label, "field-space text-small"));
        const grid = element("div", undefined, "choice-grid");
        for (const item of group.options) {
          const label = element("label", undefined, "form-check");
          const input = element("input", undefined, "form-check-input");
          input.type = q.type === "single" ? "radio" : "checkbox";
          input.name = `${root.id}-${q.id}`;
          input.value = item;
          input.checked = Array.isArray(saved.value) ? saved.value.includes(item) : saved.value === item;
          label.append(input, element("span", item, "form-check-label"));
          grid.append(label);
          valueControls.push(input);
        }
        fields.append(grid);
      }
    }
    let note;
    if (q.type !== "text") {
      note = element("textarea", undefined, "form-control");
      note.rows = 2;
      note.maxLength = 800;
      note.placeholder = "其他 / 补充（可不填）";
      note.setAttribute("aria-label", `${q.label}：其他或补充`);
      note.value = saved.note || "";
      const noteLabel = element("label", "补充内容", "form-label field-space");
      noteLabel.append(note);
      const details = element("details", undefined, "field-space");
      details.append(element("summary", "其他 / 补充（可不填）", "cursor-interaction"), noteLabel);
      details.open = Boolean(saved.note);
      fields.append(details);
    }
    block.append(fields);
    let evidence;
    if (q.evidence_select) {
      evidence = select([["experience", "我实际经历或做过的事"], ["preference", "我希望或理想中的情况"],
        ["hypothetical", "我对假设情境的回答"], ["self_description", "我的一般自我描述"]],
      "这段回答主要来自", saved.evidence || q.evidence);
      evidence.wrapper.classList.add("field-space");
      block.append(evidence.wrapper);
    }
    const status = select([["answered", "正常作答"], ["uncertain", "我不确定"],
      ["skipped", "暂时跳过"], ["declined", "不想回答"]], "这题的状态", saved.status);
    status.wrapper.classList.add("field-space");
    block.append(status.wrapper);

    function capture() {
      const previousRevision = state.revision;
      let value;
      if (q.type === "text") value = valueControls[0].value;
      else if (q.type === "rating") value = Object.fromEntries(ratingControls.filter(([, el]) => el.value).map(([key, el]) => [key, el.value]));
      else if (q.type === "multi") value = valueControls.filter((el) => el.checked).map((el) => el.value);
      else value = valueControls.find((el) => el.checked)?.value || "";
      model.answer(state, q.id, {status: status.input.value, value, note: note?.value || "",
        evidence: evidence?.input.value || saved.evidence || q.evidence,
        disclosure: state.answers[q.id]?.disclosure || "analysis_only"});
      if (state.revision !== previousRevision) {
        if (q.id === "q78") seen.delete("q79");
        invalidateCopy();
      }
    }
    function reflectStatus() {
      fields.hidden = status.input.value !== "answered";
    }
    for (const control of [...valueControls, ...ratingControls.map(([, input]) => input), ...(note ? [note] : [])]) {
      control.addEventListener("input", capture);
      control.addEventListener("change", capture);
    }
    status.input.addEventListener("change", () => {reflectStatus(); capture();});
    evidence?.input.addEventListener("change", capture);
    reflectStatus();
    return block;
  }

  function showBatch(ids) {
    if (!editing) ids = ids.filter((id) => model.plan(state).includes(id));
    view("questions");
    const container = find("[data-questions]");
    container.replaceChildren(...ids.map((id) => renderQuestion(questionMap.get(id))));
    const total = model.plan(state).length;
    const filled = [...seen].filter((id) => model.plan(state).includes(id)).length;
    const percent = total ? Math.min(100, Math.round(filled / total * 100)) : 100;
    find("[data-progress]").textContent = editing ? "修改已填资料" : `本步 ${ids.length} 题 · 已浏览 ${filled}/${total} 题`;
    const progress = find(".progress");
    progress.setAttribute("aria-valuenow", percent);
    progress.firstElementChild.style.width = `${percent}%`;
    find("[data-back]").disabled = page <= 0 || editing;
    find("[data-next]").textContent = editing ? "保存修改" : "继续";
  }

  function commitCurrent() {
    const previousRevision = state.revision;
    for (const block of find("[data-questions]").children) {
      const id = block.dataset.questionId;
      if (!state.answers[id]) model.answer(state, id, {status: "skipped"});
      seen.add(id);
    }
    if (state.revision !== previousRevision) invalidateCopy();
  }

  function next() {
    if (page >= 0 || editing) commitCurrent();
    if (editing) {editing = false; review(); return;}
    while (page < history.length - 1) {
      page++;
      if (history[page].some((id) => model.plan(state).includes(id))) {showBatch(history[page]); return;}
    }
    const remaining = model.plan(state).filter((id) => !seen.has(id));
    if (!remaining.length) {review(); return;}
    // 每步最多五题；不确定分支在后续步骤自然出现。
    history.push(remaining.slice(0, 5));
    page = history.length - 1;
    showBatch(history[page]);
  }

  function updateConsentControls() {
    const eligible = state.questions.filter((q) => model.canDisclose(state, q.id));
    const count = eligible.filter((q) => state.answers[q.id].disclosure === "public").length;
    find("[data-consent-count]").textContent = `已勾选 ${count} / ${eligible.length} 项`;
    find("[data-select-all]").disabled = busy || eligible.length === count;
    find("[data-select-none]").disabled = busy || count === 0;
    find("[data-continue]").disabled = busy;
    find("[data-edit-writing]").disabled = busy;
    for (const button of root.querySelectorAll("[data-summary] button")) button.disabled = busy;
    for (const input of root.querySelectorAll("[data-disclosure-id]")) {
      input.checked = state.answers[input.dataset.disclosureId].disclosure === "public";
      input.disabled = busy || !model.canDisclose(state, input.dataset.disclosureId);
    }
    // 仅有拒答或撤回状态也需要回传，才能清除 AI 中的旧资料。
    find("[data-submit]").disabled = busy || Object.keys(state.answers).length === 0;
    find("[data-submit]").textContent = busy ? "正在准备…" : copiedRevision === state.revision ? "重新复制答案" : "复制答案";
    find("[data-writing-panel]").hidden = !["post", "full"].includes(state.goal);
    const chosen = (id) => state.answers[id]?.status === "answered" ? state.answers[id].value : null;
    const display = (value) => model.hasValue(value) ? Array.isArray(value) ? value.join("、") : value : "未选择";
    find("[data-writing-summary]").textContent = `平台：${display(chosen("q86"))}；语气：${display(chosen("q87"))}；长度：${display(chosen("q88"))}。`;
    const privacy = model.privacyConstraints(state);
    find("[data-privacy-note]").textContent = privacy.requires_review
      ? "你填写了文字公开限制，范围尚需核对，当前个人资料均不公开。可修改第10题，改用明确选项并清除文字补充；保留文字则交给 AI 私下核对。"
      : privacy.blocked_ids.length ? "已排除的资料不会被全选公开。单题只想公开部分内容时，请先将答案改成可公开的版本，并调整公开范围规则。" : "";
    updateVariantCount();
  }

  function review() {
    view("review");
    const summary = find("[data-summary]");
    summary.replaceChildren();
    const table = element("table", undefined, "table table-sm review-table");
    table.append(element("caption", "答案汇总与详情帖公开授权", "sr-only"));
    const header = element("tr");
    for (const title of ["题目", "你的回答", "写入详情帖", "操作"]) {
      const cell = element("th", title);
      cell.scope = "col";
      header.append(cell);
    }
    const head = element("thead");
    head.append(header);
    const body = element("tbody");
    table.append(head, body);
    const statusText = {answered: "已回答", uncertain: "不确定", skipped: "已跳过", declined: "不想回答"};
    for (const q of state.questions.filter((question) => state.answers[question.id])) {
      const answer = state.answers[q.id];
      const row = element("tr");
      const title = element("th", q.display_label || q.label);
      title.scope = "row";
      row.append(title);
      const value = typeof answer.value === "object" && !Array.isArray(answer.value) && answer.value
        ? Object.entries(answer.value).map(([key, item]) => `${key}：${item}`).join("；")
        : Array.isArray(answer.value) ? answer.value.join("、") : answer.value;
      row.append(element("td", answer.status === "answered" ? [value, answer.note].filter(Boolean).join("；") : statusText[answer.status]));
      const consent = element("td");
      const label = element("label", undefined, "form-check");
      const input = element("input", undefined, "form-check-input");
      input.type = "checkbox";
      input.dataset.disclosureId = q.id;
      input.setAttribute("aria-label", `允许第 ${q.number} 题的信息写入详情帖`);
      label.append(input, element("span", model.canDisclose(state, q.id) ? "允许写入" : "不写入", "form-check-label"));
      consent.append(label);
      if (!model.canDisclose(state, q.id)) consent.append(element("span", model.disclosureReason(state, q.id), "text-muted text-small"));
      input.addEventListener("change", () => {
        model.setDisclosure(state, q.id, input.checked);
        invalidateCopy();
        updateConsentControls();
      });
      row.append(consent);
      const edit = element("button", "修改", "btn btn-ghost");
      edit.type = "button";
      edit.addEventListener("click", () => {editing = true; showBatch([q.id]);});
      const action = element("td");
      action.append(edit);
      row.append(action);
      body.append(row);
    }
    if (body.children.length) summary.append(table);
    else summary.append(element("div", "尚未填写资料，可以继续填写。"));
    find("[data-continue]").textContent = model.plan(state).some((id) => !seen.has(id)) ? "继续填写" : "返回上一步";
    updateConsentControls();
  }

  for (const [selector, enabled] of [["[data-select-all]", true], ["[data-select-none]", false]]) {
    find(selector).addEventListener("click", () => {
      model.setAllDisclosures(state, enabled);
      invalidateCopy();
      updateConsentControls();
    });
  }

  find("[data-goal]").value = state.goal;
  find("[data-mode]").value = state.mode;
  find("[data-focus]").hidden = state.mode !== "deep";
  for (const input of find("[data-focus]").querySelectorAll("input")) input.checked = state.focus.includes(input.value);
  find("[data-known]").hidden = state.prefilled.size === 0;
  find("[data-known]").addEventListener("click", review);
  find("[data-goal]").addEventListener("change", () => {state.goal = find("[data-goal]").value; state.revision++; invalidateCopy();});
  find("[data-mode]").addEventListener("change", () => {
    state.mode = find("[data-mode]").value;
    state.revision++;
    invalidateCopy();
    find("[data-focus]").hidden = state.mode !== "deep";
  });
  find("[data-begin]").addEventListener("click", () => {
    state.goal = find("[data-goal]").value;
    state.mode = find("[data-mode]").value;
    state.focus = [...find("[data-focus]").querySelectorAll("input:checked")].map((input) => input.value);
    state.revision++;
    invalidateCopy();
    history = []; page = -1; seen = new Set(Object.keys(state.answers)); editing = false;
    next();
  });
  find("[data-settings]").addEventListener("click", () => {commitCurrent(); view("start");});
  find("[data-next]").addEventListener("click", next);
  find("[data-back]").addEventListener("click", () => {
    commitCurrent();
    while (page > 0) {
      page--;
      if (history[page].some((id) => model.plan(state).includes(id))) {showBatch(history[page]); break;}
    }
  });
  find("[data-review-now]").addEventListener("click", () => {commitCurrent(); review();});
  find("[data-continue]").addEventListener("click", () => {
    editing = false;
    if (model.plan(state).some((id) => !seen.has(id))) next();
    else if (history.length) {page = history.length - 1; showBatch(history[page]);}
    else view("start");
  });
  find("[data-edit-writing]").addEventListener("click", () => {
    editing = true;
    showBatch(["q86", "q87", "q88"]);
  });
  async function copyAnswers() {
    if (busy) return;
    busy = true;
    updateConsentControls();
    find("[data-error]").hidden = true;
    find("[data-status]").textContent = "正在准备可粘贴的答案…";
    const revision = state.revision;
    try {
      const textarea = find("[data-copy-text]");
      const result = await model.copyPrompt(state, navigator.clipboard, (text) => {
        textarea.value = text;
        textarea.hidden = false;
        textarea.focus();
        textarea.select();
      });
      copiedRevision = revision;
      if (revision !== state.revision) {invalidateCopy(); return;}
      if (result.copied) {
        textarea.value = result.text;
        textarea.hidden = true;
        find("[data-status]").textContent = "答案已复制。回到刚才的 AI 对话，粘贴并发送。";
      } else {
        find("[data-status]").textContent = "浏览器未允许访问剪贴板。完整答案已显示并选中，请手动复制，再回到刚才的 AI 对话粘贴并发送。";
      }
      find("[data-handoff]").hidden = false;
      updateFlow();
    } catch (error) {
      showError(error);
    } finally {
      busy = false;
      updateConsentControls();
    }
  }
  find("[data-submit]").addEventListener("click", copyAnswers);
  find("[data-focus]").addEventListener("change", () => {
    state.focus = [...find("[data-focus]").querySelectorAll("input:checked")].map((input) => input.value);
    state.revision++;
    invalidateCopy();
  });
  find("[data-version]").textContent = config.skill_version ? `问卷版本 ${config.skill_version}` : "";
  updateVariantCount();
  updateFlow();
})();
