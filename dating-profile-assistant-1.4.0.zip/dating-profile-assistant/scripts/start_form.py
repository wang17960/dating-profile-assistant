"""为本地 AI 助手一次构建并打开问卷，不依赖安装位置或当前工作目录。"""

import argparse
import json
import sys
from pathlib import Path
from tempfile import NamedTemporaryFile

from build_form import render_form, skill_version
from open_form import open_form


def start_form(output_dir, prefill_path=None, *, no_open=False):
    """构建失败不留下页面；浏览器打开失败仍返回可用的完整文件。"""
    prefill = json.loads(Path(prefill_path).read_text(encoding="utf-8-sig")) if prefill_path else None
    document = render_form(prefill)
    directory = Path(output_dir).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    # 标准库使用独占创建和随机文件名，重复启动不覆盖现有填写页。
    with NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", suffix=".html",
                            prefix="dating-profile-questionnaire-", dir=directory, delete=False) as output:
        page = Path(output.name)
        try:
            output.write(document)
        except OSError:
            output.close()
            page.unlink(missing_ok=True)
            raise
    return {"html_path": str(page), "skill_version": skill_version(),
            "browser_opened": False if no_open else open_form(page)}


def main():
    parser = argparse.ArgumentParser(description="构建并在默认浏览器打开相亲问卷")
    parser.add_argument("--output-dir", required=True, type=Path, help="当前任务授权的输出目录")
    parser.add_argument("--prefill", type=Path, help="用户已知资料的可选 JSON 文件")
    parser.add_argument("--no-open", action="store_true", help="仅构建，用于测试或没有浏览器的环境")
    args = parser.parse_args()
    try:
        result = start_form(args.output_dir, args.prefill, no_open=args.no_open)
    except (OSError, ValueError) as error:
        print(f"问卷启动失败：{error}", file=sys.stderr)
        return 1
    # ASCII JSON 避免不同助手及 Windows 终端编码破坏中文路径。
    print(json.dumps(result, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
