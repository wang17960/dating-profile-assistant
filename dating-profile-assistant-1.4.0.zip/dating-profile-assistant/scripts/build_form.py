"""从 Markdown 题库生成能回传当前 AI 的网页问卷。仅使用标准库。"""

import argparse
import json
import re
import uuid
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
EVIDENCE_TYPES = {"experience", "preference", "hypothetical", "self_description"}


def load_questions(root=SKILL_ROOT):
    """题目标题只从题库读取，控件文件不另存一份题目。"""
    markdown = (root / "questionnaire.md").read_text(encoding="utf-8")
    controls = json.loads((root / "assets/form-controls.json").read_text(encoding="utf-8"))
    interests = []
    personality = []
    for line in markdown.splitlines():
        if re.match(r"^- \*\*(娱乐|运动|艺术文化|生活|兴趣领域|日常社交)\*\*", line):
            group, options = line.split("：", 1)
            interests.append({"label": group.split("**")[1], "options": options.rstrip("。").split("、")})
        if line.startswith("不要要求用户自封人格类型。"):
            personality = line.split("：", 1)[1].rstrip("。").split("、")
    questions = []
    section = ""
    for line in markdown.splitlines():
        heading = re.match(r"## \d+\. (.+)", line)
        if heading:
            section = heading[1]
        match = re.match(r"(\d+)\. (.+)", line)
        if not match:
            continue
        number = int(match[1])
        qid = f"q{number:02d}"
        question = {"id": qid, "number": number, "section": section,
                    "label": match[2], "type": "text", "options": [],
                    "source": "FACT" if number in {2, 3, 4, 5, 6, 9, 11} else "SELF_REPORT",
                    "writing": number >= 86, "sensitive": number in {8, 9, 10, 47, 49, 60, 73}}
        question["kind"] = "privacy_rule" if number in {8, 10} else "writing" if number >= 86 else "personal"
        question["evidence"] = ("experience" if number in {37, 52, 56, 60, 84}
                                else "preference" if 41 <= number <= 51 or 61 <= number <= 81
                                else "hypothetical" if number in {53, 54, 57, 59}
                                else "self_description")
        question["evidence_select"] = number in {37, 52, 53, 54, 56, 57, 60, 76, 84}
        question.update(controls.get(qid, {}))
        if question.pop("options_from", None) == "interests":
            question["groups"] = interests
            question["options"] = [item for group in interests for item in group["options"]]
        elif qid == "q33":
            question["options"] = personality
        # 已有原生选项时，标题不再重复枚举同一组候选答案。
        question["display_label"] = (question["label"].split("：", 1)[0]
                                     if question["type"] != "text" else question["label"])
        questions.append(question)
    ids = [q["id"] for q in questions]
    if len(ids) != len(set(ids)) or ids != [f"q{i:02d}" for i in range(1, 90)]:
        raise ValueError("题库编号必须恰好为 1–89 且无重复；改题号时同步更新网页模式和测试。")
    if set(controls) - set(ids):
        raise ValueError("网页控件存在无法匹配的题号。")
    return questions


def validate_prefill(prefill, questions):
    """只接受明确的用户资料；推断不得预填成已答事实。"""
    known = {q["id"]: q for q in questions}
    if not isinstance(prefill, dict):
        raise ValueError("预填文件应为对象。")
    answers = prefill.get("answers", {})
    if not isinstance(answers, dict):
        raise ValueError("预填 answers 应为题号到答案的对象。")
    focus = prefill.get("focus", [])
    if not isinstance(focus, list) or any(not isinstance(v, str) or v not in {
            "self", "relationship", "values", "preferences"} for v in focus):
        raise ValueError("深度主题应为合法主题的字符串数组。")
    for qid, answer in answers.items():
        if qid not in known or not isinstance(answer, dict):
            raise ValueError(f"无效的预填题号或答案：{qid}")
        if answer.get("source") == "INFERENCE":
            raise ValueError("不能把推断预填为用户答案。")
        if answer.get("source", "SELF_REPORT") not in ("FACT", "SELF_REPORT"):
            raise ValueError("无效的资料来源。")
        if answer.get("evidence", "self_description") not in tuple(EVIDENCE_TYPES):
            raise ValueError("无效的依据类型。")
        if not isinstance(answer.get("note", ""), str):
            raise ValueError("答案补充应为文字。")
        value = answer.get("value")
        valid_value = value is None or isinstance(value, str)
        if isinstance(value, list):
            valid_value = all(isinstance(v, str) for v in value)
        elif isinstance(value, dict):
            valid_value = known[qid]["type"] == "rating" and all(
                isinstance(k, str) and isinstance(v, str) for k, v in value.items())
        if not valid_value:
            raise ValueError("答案应为文字、文字数组或评分对象。")
        if isinstance(value, list) and known[qid]["type"] not in {"multi", "text"}:
            raise ValueError("该题不能接收数组答案。")
        if answer.get("disclosure", "analysis_only") not in ("public", "analysis_only"):
            raise ValueError("无效的公开权限。")
        if answer.get("status", "answered") not in ("answered", "uncertain", "skipped", "declined"):
            raise ValueError("无效的答案状态。")
    if prefill.get("mode", "quick") not in ("quick", "standard", "deep"):
        raise ValueError("无效的问卷模式。")
    if prefill.get("goal", "post") not in ("post", "profile", "preferences", "report", "full"):
        raise ValueError("无效的问卷目标。")


def normalize_writing_prefill(prefill, questions):
    """兼容旧版标量预填，并清除平台和语气题中的无效选项。"""
    normalized = dict(prefill)
    answers = dict(prefill.get("answers", {}))
    questions_by_id = {question["id"]: question for question in questions}
    for qid in ("q86", "q87"):
        if qid not in answers:
            continue
        answer = dict(answers[qid])
        selected = answer.get("value")
        candidates = selected if isinstance(selected, list) else [selected]
        allowed = set(questions_by_id[qid]["options"])
        answer["value"] = list(dict.fromkeys(
            item.strip() for item in candidates
            if isinstance(item, str) and item.strip() in allowed
        ))
        answers[qid] = answer
    normalized["answers"] = answers
    return normalized


def skill_version(root=SKILL_ROOT):
    """版本仅从 Skill 入口读取，问卷与分发包共用。"""
    version = re.search(r'(?m)^  version: "([\d.]+)"$', (root / "SKILL.md").read_text(encoding="utf-8"))
    if not version:
        raise ValueError("Skill 入口应在 metadata 中声明字符串 version。")
    return version[1]


def render_form(prefill=None, root=SKILL_ROOT):
    questions = load_questions(root)
    prefill = {} if prefill is None else prefill
    validate_prefill(prefill, questions)
    prefill = normalize_writing_prefill(prefill, questions)
    config = {"schema_version": 1, "skill_version": skill_version(root),
              "skill_path": str(root.resolve() / "SKILL.md"),
              "questions": questions, "prefill": prefill}
    # 阻止用户文本闭合 JSON script 元素，所有显示文本仍由 textContent 输出。
    data = json.dumps(config, ensure_ascii=False).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    shell = (root / "assets/form-shell.html").read_text(encoding="utf-8")
    model = (root / "assets/form-model.js").read_text(encoding="utf-8")
    ui = (root / "assets/form-ui.js").read_text(encoding="utf-8")
    styles = (root / "assets/local-form.css").read_text(encoding="utf-8")
    instance = "dating-form-" + uuid.uuid4().hex[:10]
    # 仅替换原模板中的占位符，不再对插入后的用户文字执行替换。
    replacements = {"__ROOT_ID__": instance, "__DATA__": data, "__MODEL__": model,
                    "__UI__": ui.replace("__ROOT_ID__", instance)}
    fragment = re.sub(r"__ROOT_ID__|__DATA__|__MODEL__|__UI__", lambda m: replacements[m[0]], shell)
    return ("<!doctype html>\n<html lang=\"zh-CN\">\n<head>\n"
            "<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
            "<meta name=\"color-scheme\" content=\"light\">\n<title>相亲自我画像问卷</title>\n"
            f"<style>\n{styles}\n</style>\n</head>\n<body>\n{fragment}\n</body>\n</html>\n")


def main():
    parser = argparse.ArgumentParser(description="生成 Skill 的网页问卷")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--prefill", type=Path)
    args = parser.parse_args()
    prefill = json.loads(args.prefill.read_text(encoding="utf-8-sig")) if args.prefill else {}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render_form(prefill), encoding="utf-8")
    print(str(args.output.resolve()))


if __name__ == "__main__":
    main()
