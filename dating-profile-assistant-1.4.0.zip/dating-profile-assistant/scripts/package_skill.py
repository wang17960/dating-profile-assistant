"""仅打包运行资源和合成测试资料，排除原始帖子、真实填写页和临时输出。"""

import argparse
import hashlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from build_form import SKILL_ROOT, skill_version


ROOT_FILES = {
    ".gitignore", "SKILL.md", "README.md", "questionnaire.md", "preference-analysis.md",
    "relationship-analysis.md", "dating-report-template.md", "writing-guide.md",
    "privacy-safety.md", "web-interaction.md",
}
RESOURCE_FILES = {
    "agents": {"openai.yaml"},
    "assets": {"form-controls.json", "form-model.js", "form-ui.js", "form-shell.html", "local-form.css"},
    "scripts": {"build_form.py", "open_form.py", "start_form.py", "package_skill.py"},
    "styles": {"xiaohongshu.md", "douban.md", "weibo.md", "douyin.md", "moments.md", "dating-group.md", "generic.md"},
    "tests": {"scenarios.md", "test_build_form.py", "test_start_form.py", "test_package.py", "form-model.test.cjs",
              "quality-model.test.cjs", "helpers.cjs", "content-fixtures.test.cjs",
              "content-cases.json", "content-evaluation.md", "browser.test.cjs"},
}
REFERENCES = {
    "references/README.md", "references/synthetic-examples.md",
    "references/xiaohongshu/README.md", "references/douban/README.md",
}


def collect_files(root=SKILL_ROOT):
    """根文件与参考资料白名单避免把个人素材顺手带入分发包。"""
    files = []
    for item in sorted(root.rglob("*")):
        if not item.is_file() or item.is_symlink():
            continue
        relative = item.relative_to(root)
        if "__pycache__" in relative.parts:
            continue
        allowed = (relative.as_posix() in REFERENCES or len(relative.parts) == 1
                   and item.name in ROOT_FILES or len(relative.parts) == 2
                   and item.name in RESOURCE_FILES.get(relative.parts[0], set()))
        if allowed:
            files.append(item)
    return files


def package_skill(output, root=SKILL_ROOT):
    """生成带单一 Skill 根目录的 ZIP，并返回校验值与版本。"""
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    version = skill_version(root)
    files = collect_files(root)
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        for item in files:
            archive.write(item, f"dating-profile-assistant/{item.relative_to(root).as_posix()}")
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    return {"version": version, "files": len(files), "sha256": digest, "path": str(output.resolve())}


def main():
    parser = argparse.ArgumentParser(description="构建不含个人素材的 Skill 分发 ZIP")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = package_skill(args.output)
    print(f"版本 {result['version']}，共 {result['files']} 个文件：{result['path']}")
    print(f"SHA256: {result['sha256']}")


if __name__ == "__main__":
    main()
