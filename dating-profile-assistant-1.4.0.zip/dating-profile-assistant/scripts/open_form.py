"""将本地问卷交给系统默认浏览器打开。"""

import argparse
import sys
import webbrowser
from pathlib import Path


def open_form(path: Path, opener=webbrowser.open) -> bool:
    """打开已生成的 HTML；路径无效或浏览器拒绝时返回 False。"""
    try:
        page = Path(path).resolve(strict=True)
        if not page.is_file():
            raise FileNotFoundError(page)
        opened = opener(page.as_uri(), new=2)
        if not opened:
            raise RuntimeError("系统默认浏览器未能打开问卷。")
        return True
    except (OSError, RuntimeError, ValueError) as error:
        print(f"无法打开本地问卷：{error}", file=sys.stderr)
        return False


def main() -> int:
    parser = argparse.ArgumentParser(description="在系统默认浏览器中打开相亲画像问卷")
    parser.add_argument("html", type=Path, help="由 build_form.py 生成的 HTML 文件")
    args = parser.parse_args()
    return 0 if open_form(args.html) else 1


if __name__ == "__main__":
    raise SystemExit(main())
